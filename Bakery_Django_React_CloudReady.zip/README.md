# Bakery Internal — Cloud-Ready (Railway + Vercel)
Follow the deploy guide I shared. Backend uses Postgres via DATABASE_URL, Whitenoise for static, and env CORS/CSRF.
