from rest_framework import serializers
from .models import Shop, Product, Sale, Expense, Ingredient, InventoryTxn, Staff

class ShopSerializer(serializers.ModelSerializer):
    class Meta: model = Shop; fields = "__all__"

class ProductSerializer(serializers.ModelSerializer):
    class Meta: model = Product; fields = "__all__"

class SaleSerializer(serializers.ModelSerializer):
    class Meta: model = Sale; fields = "__all__"

class ExpenseSerializer(serializers.ModelSerializer):
    class Meta: model = Expense; fields = "__all__"

class IngredientSerializer(serializers.ModelSerializer):
    class Meta: model = Ingredient; fields = "__all__"

class InventoryTxnSerializer(serializers.ModelSerializer):
    class Meta: model = InventoryTxn; fields = "__all__"

class StaffSerializer(serializers.ModelSerializer):
    class Meta: model = Staff; fields = "__all__"
