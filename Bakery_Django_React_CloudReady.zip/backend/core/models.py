from django.db import models

class Shop(models.Model):
    name = models.CharField(max_length=200)
    city = models.CharField(max_length=100, default="")
    manager = models.CharField(max_length=100, default="")
    def __str__(self): return self.name

class Product(models.Model):
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=50)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    def __str__(self): return self.name

class Sale(models.Model):
    date = models.DateField()
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    unit_price = models.DecimalField(max_digits=10, decimal_places=2)
    line_total = models.DecimalField(max_digits=12, decimal_places=2)

class Expense(models.Model):
    date = models.DateField()
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE)
    category = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=12, decimal_places=2)

class Ingredient(models.Model):
    name = models.CharField(max_length=100)
    unit = models.CharField(max_length=20)

class InventoryTxn(models.Model):
    TXN_TYPES = (("Usage", "Usage"), ("Purchase", "Purchase"))
    date = models.DateField()
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    txn_type = models.CharField(max_length=20, choices=TXN_TYPES)
    quantity = models.DecimalField(max_digits=10, decimal_places=3)

class Staff(models.Model):
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=50)
    shop = models.ForeignKey(Shop, on_delete=models.CASCADE)
    join_date = models.DateField()
