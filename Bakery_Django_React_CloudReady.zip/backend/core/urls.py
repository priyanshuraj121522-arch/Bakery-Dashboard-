from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    ShopViewSet, ProductViewSet, SaleViewSet, ExpenseViewSet,
    IngredientViewSet, InventoryTxnViewSet, StaffViewSet, kpi_summary
)

router = DefaultRouter()
router.register(r'shops', ShopViewSet)
router.register(r'products', ProductViewSet)
router.register(r'sales', SaleViewSet)
router.register(r'expenses', ExpenseViewSet)
router.register(r'ingredients', IngredientViewSet)
router.register(r'inventory', InventoryTxnViewSet)
router.register(r'staff', StaffViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('kpi/summary/', kpi_summary),
]
