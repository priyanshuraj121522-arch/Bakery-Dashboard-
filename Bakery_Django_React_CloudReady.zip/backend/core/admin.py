from django.contrib import admin
from .models import Shop, Product, Sale, Expense, Ingredient, InventoryTxn, Staff
admin.site.register(Shop)
admin.site.register(Product)
admin.site.register(Sale)
admin.site.register(Expense)
admin.site.register(Ingredient)
admin.site.register(InventoryTxn)
admin.site.register(Staff)
