from rest_framework import viewsets, permissions, decorators, response
from django.db.models import Sum
from .models import Shop, Product, Sale, Expense, Ingredient, InventoryTxn, Staff
from .serializers import (
    ShopSerializer, ProductSerializer, SaleSerializer, ExpenseSerializer,
    IngredientSerializer, InventoryTxnSerializer, StaffSerializer
)

class BaseViewSet(viewsets.ModelViewSet):
    permission_classes = [permissions.IsAuthenticated]

class ShopViewSet(BaseViewSet):
    queryset = Shop.objects.all()
    serializer_class = ShopSerializer

class ProductViewSet(BaseViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class SaleViewSet(BaseViewSet):
    queryset = Sale.objects.order_by("date","id")
    serializer_class = SaleSerializer

class ExpenseViewSet(BaseViewSet):
    queryset = Expense.objects.order_by("date","id")
    serializer_class = ExpenseSerializer

class IngredientViewSet(BaseViewSet):
    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer

class InventoryTxnViewSet(BaseViewSet):
    queryset = InventoryTxn.objects.order_by("date","id")
    serializer_class = InventoryTxnSerializer

class StaffViewSet(BaseViewSet):
    queryset = Staff.objects.order_by("join_date","id")
    serializer_class = StaffSerializer

@decorators.api_view(["GET"])
def kpi_summary(request):
    q_sales = Sale.objects.aggregate(total=Sum("line_total"))["total"] or 0
    q_exp = Expense.objects.aggregate(total=Sum("amount"))["total"] or 0
    return response.Response({
        "total_sales": float(q_sales),
        "total_expenses": float(q_exp),
        "profit": float(q_sales - q_exp),
    })
