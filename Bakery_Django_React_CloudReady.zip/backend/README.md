Cloud-ready backend for Railway. See root README for deploy steps.
