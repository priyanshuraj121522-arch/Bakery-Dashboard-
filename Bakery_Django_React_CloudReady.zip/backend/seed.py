from core.models import Shop, Product, Ingredient
from django.db import transaction

@transaction.atomic
def run():
    if Shop.objects.count() == 0:
        Shop.objects.bulk_create([
            Shop(name="Central Bakery - MG Road", city="Patna", manager="Anita"),
            Shop(name="Sunrise Bakery - North", city="Patna", manager="Rohit"),
            Shop(name="Riverside Bakery - South", city="Patna", manager="Meera"),
        ])
    if Product.objects.count() == 0:
        Product.objects.bulk_create([
            Product(name="Sourdough Bread", category="Bread", unit_price=70),
            Product(name="Multigrain Bread", category="Bread", unit_price=65),
            Product(name="Chocolate Croissant", category="Pastry", unit_price=55),
            Product(name="Butter Croissant", category="Pastry", unit_price=50),
            Product(name="Blueberry Muffin", category="Muffin", unit_price=40),
            Product(name="Banana Muffin", category="Muffin", unit_price=35),
            Product(name="Paneer Puff", category="Savory", unit_price=45),
            Product(name="Veg Puff", category="Savory", unit_price=40),
            Product(name="Chocolate Cake 1/2kg", category="Cake", unit_price=350),
            Product(name="Black Forest 1/2kg", category="Cake", unit_price=380),
        ])
    if Ingredient.objects.count() == 0:
        Ingredient.objects.bulk_create([
            Ingredient(name="Flour", unit="kg"),
            Ingredient(name="Sugar", unit="kg"),
            Ingredient(name="Butter", unit="kg"),
            Ingredient(name="Yeast", unit="g"),
            Ingredient(name="Eggs", unit="pcs"),
            Ingredient(name="Milk", unit="L"),
            Ingredient(name="Blueberries", unit="kg"),
            Ingredient(name="Chocolate", unit="kg"),
            Ingredient(name="Paneer", unit="kg"),
            Ingredient(name="Vegetables", unit="kg"),
        ])
    print("Seed complete.")
