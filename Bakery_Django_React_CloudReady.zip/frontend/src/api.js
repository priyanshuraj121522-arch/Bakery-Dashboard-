const API_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000';
export async function login(username, password){
  const res = await fetch(`${API_URL}/api/token/`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({username,password}) });
  if(!res.ok) throw new Error('Invalid credentials'); const data = await res.json();
  localStorage.setItem('token', data.access); localStorage.setItem('refresh', data.refresh); return data;
}
function authHeaders(){ const t=localStorage.getItem('token'); return { 'Authorization':`Bearer ${t}`, 'Content-Type':'application/json' }; }
export async function apiGet(path){ const res = await fetch(`${API_URL}${path}`, { headers: authHeaders() }); if(res.status===401) throw new Error('Unauthorized'); return res.json(); }
export async function apiPost(path, body){ const res = await fetch(`${API_URL}${path}`, { method:'POST', headers: authHeaders(), body: JSON.stringify(body) }); if(!res.ok) throw new Error(await res.text()); return res.json(); }
