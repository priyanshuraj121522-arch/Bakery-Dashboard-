import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { login } from '../api'
export default function Login(){
  const [username, setU] = useState('')
  const [password, setP] = useState('')
  const [err, setErr] = useState('')
  const nav = useNavigate()
  const onSubmit = async (e)=>{
    e.preventDefault(); setErr('')
    try{ await login(username, password); nav('/dashboard') }catch(e){ setErr(e.message || 'Login failed') }
  }
  return (<div>
    <div className="nav"><div>🍞 Bakery Control Center</div></div>
    <div className="container" style={{maxWidth:420}}>
      <div className="card"><h3>Sign in</h3>
        <form onSubmit={onSubmit}>
          <label>Username</label><input className="input" value={username} onChange={e=>setU(e.target.value)}/>
          <label style={{marginTop:10}}>Password</label><input type="password" className="input" value={password} onChange={e=>setP(e.target.value)}/>
          <button className="btn" style={{marginTop:12, width:'100%'}}>Login</button>
          {err && <small className="muted">{err}</small>}
        </form>
      </div></div></div>)
}
