import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { apiGet, apiPost } from '../api'
import { Line } from 'react-chartjs-2'
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js'
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend)
export default function Dashboard(){
  const nav = useNavigate()
  const [kpi, setKpi] = useState({ total_sales:0, total_expenses:0, profit:0 })
  const [shops, setShops] = useState([])
  const [products, setProducts] = useState([])
  const [sales, setSales] = useState([])
  const [form, setForm] = useState({ shop: '', product: '', quantity: 1, unit_price: 50 })
  const [msg, setMsg] = useState('')
  async function loadAll(){
    try{
      const [k, s, p, sl] = await Promise.all([
        apiGet('/api/kpi/summary/'), apiGet('/api/shops/'), apiGet('/api/products/'), apiGet('/api/sales/')
      ]); setKpi(k); setShops(s); setProducts(p); setSales(sl)
      if(s.length && !form.shop) setForm(f=>({...f, shop: s[0].id}))
      if(p.length && !form.product) setForm(f=>({...f, product: p[0].id, unit_price: p[0].unit_price}))
    }catch(e){ nav('/login') }
  }
  useEffect(()=>{ loadAll() }, [])
  const chartData = { labels: sales.slice(-20).map(s=>s.date), datasets: [{ label: 'Line Total', data: sales.slice(-20).map(s=>s.line_total) }] }
  async function addSale(){
    const body = { date: new Date().toISOString().slice(0,10), shop: form.shop, product: form.product,
      quantity: Number(form.quantity), unit_price: Number(form.unit_price), line_total: Number(form.quantity)*Number(form.unit_price) }
    try{ await apiPost('/api/sales/', body); setMsg('✅ Sale added'); loadAll() }catch(e){ setMsg('❌ '+(e.message||'Failed')) }
  }
  return (<div>
    <div className="nav"><div>🍞 Bakery Control Center</div><button className="btn" onClick={()=>{localStorage.clear(); nav('/login')}}>Logout</button></div>
    <div className="container">
      <div className="grid">
        <div className="card"><div className="kpi">Total Sales</div><h2>₹{Math.round(kpi.total_sales)}</h2></div>
        <div className="card"><div className="kpi">Total Expenses</div><h2>₹{Math.round(kpi.total_expenses)}</h2></div>
        <div className="card"><div className="kpi">Profit</div><h2>₹{Math.round(kpi.profit)}</h2></div>
      </div>
      <div className="grid" style={{marginTop:16}}>
        <div className="card"><h4>Sales (last 20)</h4><Line data={chartData}/></div>
        <div className="card"><h4>Quick add sale</h4>
          <label>Shop</label><select className="input" value={form.shop} onChange={e=>setForm(f=>({...f, shop: e.target.value}))}>{shops.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
          <label style={{marginTop:8}}>Product</label><select className="input" value={form.product} onChange={e=>{const p=products.find(x=>x.id==e.target.value);setForm(f=>({...f, product:e.target.value, unit_price:p?.unit_price||f.unit_price}))}}>{products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:8}}>
            <div><label>Qty</label><input className="input" type="number" min="1" value={form.quantity} onChange={e=>setForm(f=>({...f, quantity:e.target.value}))}/></div>
            <div><label>Unit Price</label><input className="input" type="number" min="0" value={form.unit_price} onChange={e=>setForm(f=>({...f, unit_price:e.target.value}))}/></div>
          </div>
          <button className="btn" style={{marginTop:10}} onClick={addSale}>Add</button>
          <div><small className="muted">{msg}</small></div>
        </div>
      </div>
    </div>
  </div>)
}
